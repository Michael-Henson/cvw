Project completed by Michael Henson & Brandon Isaac

Project located in project.s. Works fully when run with sail.

Working result located in log file. 
